package ru.lesson1;

public interface Account {

    void put(double amount);

    void take(double amount);

    double getAmount();

}
